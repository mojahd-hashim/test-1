# -*- coding: utf-8 -*-
{
    "name": "Holidays Custom",
    "version": "17.0",
    "author": "Pas-SA",
    "summary": "",
    "category": "Hr",
    'depends': ['hr_holidays'],
    'data': [
        "views/views.xml",
    ],
}
