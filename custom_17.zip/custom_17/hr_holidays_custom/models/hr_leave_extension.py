from odoo import fields, models, api


class LeaveExtension(models.Model):
    _name = "hr.leave.extension"
    _description = "Leave Extension"

    leave_id = fields.Many2one(
        comodel_name='hr.leave',
        string='Leave',
        required=True)
    extension_date = fields.Date(
        string='Extension Date',
        required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('approved', 'Approved'),
        ('cancelled', 'Cancelled')],
        string='Status',
        default='draft')
