from odoo import fields, models


class LeaveCancellation(models.Model):
    _name = "hr.leave.cancellation"
    _description = "Leave Cancellation"

    leave_id = fields.Many2one(
        comodel_name='hr.leave',
        string='Leave',
        required=True)
    cancellation_date = fields.Date(
        string='Cancellation Date',
        required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('send', 'Send'),
        ('approved', 'Approved'),
        ('cancelled', 'Cancelled')],
        string='Status',
        default='draft')

    def action_send(self):
        self.state = 'send'

    def action_approve(self):
        self.state = 'approved'
        self.leave_id._remove_delegate_permissions()

    def action_cancel(self):
        self.state = 'cancelled'


class LeaveReturn(models.Model):
    _name = "hr.leave.return"
    _description = "Leave Return"

    leave_id = fields.Many2one(
        comodel_name='hr.leave',
        string='Leave',
        required=True)
    return_date = fields.Date(
        string='Return Date',
        required=True)
    state = fields.Selection([
        ('draft', 'Draft'),
        ('send', 'Send'),
        ('approved', 'Approved'),
        ('cancelled', 'Cancelled')],
        string='Status',
        default='draft')

    def action_send(self):
        self.state = 'send'

    def action_approve(self):
        self.state = 'approved'
        self.leave_id._remove_delegate_permissions()

    def action_cancel(self):
        self.state = 'cancelled'
