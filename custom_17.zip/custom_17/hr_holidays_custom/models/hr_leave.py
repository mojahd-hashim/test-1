from odoo import models, fields, api


class LeaveTypeCustom(models.Model):
    _inherit = "hr.leave.type"
    _description = "Leave Type"

    need_alternative = fields.Boolean(
        string='Leave Need Alternative?',
        help='When activated: Submitting a leave request of this type will require the appointment of an alternative employee.',
        required=False)
    must_linked = fields.Boolean(
        string='Must be Linked?',
        help='Whether the leave must be linked to an alternative.',
        required=False)


class LeaveCustom(models.Model):
    _inherit = "hr.leave"
    _description = "Leave"

    alternative_id = fields.Many2one(
        comodel_name='hr.employee',
        string='Alternative Employee',
        help='Employee who will act as an alternative during the leave.',
        required=False)
    need_alternative = fields.Boolean(
        string='Leave Need Alternative?',
        related='holiday_status_id.need_alternative',
        store=True)
    delegate_access = fields.Boolean(
        string='Delegate Access',
        help='Delegate all access rights and manager roles to the alternative employee.',
        required=False)
    must_linked = fields.Boolean(
        string='Must be Linked?',
        related='holiday_status_id.must_linked',
        store=True)
    leave_balance = fields.Float(string='Leave Balance')
    remaining_balance = fields.Float(
        string='Remaining Balance',
        # compute='_compute_remaining_balance'
    )
    cancellation_duration = fields.Float(
        string='Cancellation Duration',
        help='Duration of leave cancellation if any.',
        required=False)
    extension_date = fields.Date(
        string='Extension Date',
        help='Date of leave extension.',
        required=False)

    permissions_to_delegate_ids = fields.Many2many(
        comodel_name='res.groups',
        string='Permissions to Delegate',
        help='Permissions that will be delegated to the alternative employee.')
    managed_departments_ids = fields.Many2many(
        comodel_name='hr.department',
        string='Managed Departments',
        help='Departments managed by the employee.')
    subordinate_employees_ids = fields.One2many(
        comodel_name='hr.employee',
        inverse_name='parent_id',
        string='Direct Reports',
        help='Employees who subordinate to this employee.')
    companies_ids = fields.Many2many(
        comodel_name='res.company',
        string='Companies',
        help='Companies the employee is associated with.')

    @api.onchange('holiday_status_id')
    def _compute_leave_balance(self):
        for record in self:
            leave_balance = self.env['hr.leave.allocation'].search(
                [('employee_id', 'in', self.employee_ids.ids),
                 ('holiday_status_id', '=', self.holiday_status_id.id)], limit=1)
            remaining_leaves = self.env['hr.leave'].search(
                [('employee_ids', '=', self.employee_ids),
                 ('holiday_status_id', '=', self.holiday_status_id.id),
                 ('state', '=', 'validate')])

            record.leave_balance = leave_balance.number_of_days_display - remaining_leaves.mapped(
                'number_of_days_display')

    @api.onchange('holiday_status_id')
    def _compute_remaining_balance(self):
        for record in self:
            record.remaining_balance = record.leave_balance - record.number_of_days_display

    @api.onchange('delegate_access')
    def _onchange_delegate_access(self):
        for record in self:
            if record.delegate_access and record.alternative_id:
                current_employee = record.employee_id
                alternative_employee = record.alternative_id
                current_user = current_employee.user_id
                alternative_user = alternative_employee.user_id
                if not current_user or not alternative_user:
                    return
                # Delegate permissions
                # To select only groups that don't already exist for the alternative employee
                groups_ids = []
                for group in current_user.groups_id.ids:
                    if group not in alternative_user.groups_id.ids:
                        groups_ids.append(group)
                record.permissions_to_delegate_ids = [(6, 0, groups_ids)]
                # Delegate managed departments
                departments = self.env['hr.department'].search([('manager_id', '=', current_employee.id)])
                record.managed_departments_ids = [(6, 0, departments.ids)]
                # Delegate direct reports
                direct_staff = self.env['hr.employee'].search([('parent_id', '=', current_employee.id)])
                record.subordinate_employees_ids = [(6, 0, direct_staff.ids)]
                # Delegate companies
                record.companies_ids = [(6, 0, current_user.company_ids.ids)]
            else:
                record.permissions_to_delegate_ids = False
                record.managed_departments_ids = False
                record.subordinate_employees_ids = False
                record.companies_ids = False

    def _delegate_permissions(self):
        for record in self:
            if record.delegate_access and record.alternative_id:
                current_employee = record.employee_id
                alternative_employee = record.alternative_id
                current_user = current_employee.user_id
                alternative_user = alternative_employee.user_id
                if current_user and alternative_user:
                    # Delegate permissions
                    for group in record.permissions_to_delegate_ids:
                        if group not in alternative_user.groups_id:
                            alternative_user.groups_id = [(4, group.id)]
                    # Delegate managed departments
                    for department in record.managed_departments_ids:
                        if department.manager_id == current_employee:
                            department.manager_id = alternative_employee
                    # Delegate direct staff
                    for employee in record.subordinate_employees_ids:
                        employee.parent_id = alternative_employee
                        employee.coach_id = alternative_employee
                    # Delegate companies
                    for company in record.companies_ids:
                        if company not in alternative_user.company_ids:
                            alternative_user.company_ids = [(4, company.id)]

    def _remove_delegate_permissions(self):
        for record in self:
            current_employee = record.employee_id
            current_user = current_employee.user_id
            alternative_employee = record.alternative_id
            alternative_user = alternative_employee.user_id
            if not current_user or not alternative_user:
                return
            # Remove delegated permissions
            alternative_user.groups_id = [(3, group.id) for group in record.permissions_to_delegate_ids]
            # Revert managed departments
            for department in record.managed_departments_ids:
                if department.manager_id == alternative_employee:
                    department.manager_id = current_employee
            # Revert direct
            for employee in record.subordinate_employees_ids:
                if employee.parent_id == alternative_employee:
                    employee.parent_id = current_employee
                    employee.coach_id = current_employee
            # # Revert companies
            # if record.companies_ids:
            #     alternative_user.company_ids = [(3, company.id) for company in record.companies_ids]

    def action_approve(self):
        res = super(LeaveCustom, self).action_approve()
        self._delegate_permissions()
        return res

    def action_refuse(self):
        res = super(LeaveCustom, self).action_refuse()
        self._remove_delegate_permissions()
        return res


